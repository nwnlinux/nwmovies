#define _NWMOVIES_VERSION "20171112"
#define _NWMOVIES_LOGFILE "nwmovies.log"
#define _NWMOVIES_PLAYER "ffplay -fs -autoexit -exitonkeydown -exitonmousedown"

void NWMovies_log(const int echo, const char *fmt, ...);
